﻿(function (controllers, undefined) {

    /**
     * @ngdoc controller
     * @name Merchello.Dashboards.Settings.Notifications.Dialogs.NotificationsEditTemplateController
     * @function
     * 
     * @description
     * The controller for updating email templates
     */
	controllers.NotificationsEditTemplateController = function ($scope) {

   
    };

	angular.module("umbraco").controller("Merchello.Dashboards.Settings.Notifications.Dialogs.NotificationsEditTemplateController", ['$scope', merchello.Controllers.NotificationsEditTemplateController]);


}(window.merchello.Controllers = window.merchello.Controllers || {}));
