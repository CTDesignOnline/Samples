﻿(function (controllers, undefined) {

    /**
     * @ngdoc controller
     * @name Merchello.Dashboards.Settings.Shipping.Dialogs.ShippingDeleteWarehouseController
     * @function
     * 
     * @description
     * The controller for deleting a warehouse
     */
	controllers.ShippingDeleteWarehouseController = function ($scope) {

    };

	angular.module("umbraco").controller("Merchello.Dashboards.Settings.Shipping.Dialogs.ShippingDeleteWarehouseController", ['$scope', merchello.Controllers.ShippingDeleteWarehouseController]);


}(window.merchello.Controllers = window.merchello.Controllers || {}));
