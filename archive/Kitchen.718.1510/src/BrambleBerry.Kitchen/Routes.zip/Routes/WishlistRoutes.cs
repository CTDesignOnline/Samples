﻿namespace BrambleBerry.Kitchen.Routes
{
    using System.Web.Routing;
    using Logic;
    using Umbraco.Web.PublishedCache;
    using System.Web.Mvc;

    internal static class WishlistRoutes
    {
        /// <summary>
        /// maps all the routes for the Public Wishlist Pages
        /// </summary>
        /// <param name="routes"></param>
        /// <param name="umbracoCache"></param>
        internal static void MapRoutes(RouteCollection routes, ContextualPublishedCache umbracoCache)
        {
            routes.MapUmbracoRoute(
                "wishlistSharedPage",
                "Wishlist/{customerId}/{wishlistName}",
                new
                {
                    controller = "Wishlist",
                    action = "View",
                    wishlistName =UrlParameter.Optional
                },
                new UmbracoVirtualNodeByIdRouteHandler(1120));
        }

    }
}
