﻿namespace BrambleBerry.Kitchen.Routes
{
    using System.Web.Routing;
    using Logic;
    using Umbraco.Web.PublishedCache;
    using System.Web.Mvc;

    internal static class AuthorizationRoutes
    {
        internal static void MapRoutes(RouteCollection routes, ContextualPublishedCache umbracoCache)
        {
            int nodeid = 1120;
            string firstUrlSegment = "Authorization";


            routes.MapUmbracoRoute(
                    "authResetPassword",
                    firstUrlSegment + "/ResetPassword/{token}/{memberId}",
                    new
                    {
                        controller = "Authorization",
                        action = "ResetPassword",
                    },
                    new UmbracoVirtualNodeByIdRouteHandler(nodeid));


            routes.MapUmbracoRoute(
               "auth",
               firstUrlSegment + "/{action}",
               new
               {
                   controller = "Authorization",
                   action = "Index",
               },
               new UmbracoVirtualNodeByIdRouteHandler(nodeid));


        }

    }
}
