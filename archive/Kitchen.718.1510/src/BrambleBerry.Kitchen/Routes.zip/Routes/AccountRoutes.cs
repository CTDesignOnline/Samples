﻿namespace BrambleBerry.Kitchen.Routes
{
    using System.Web.Routing;
    using Logic;
    using Umbraco.Web.PublishedCache;
    using System.Web.Mvc;

    internal static class AccountRoutes
    {
        internal static void MapRoutes(RouteCollection routes, ContextualPublishedCache umbracoCache)
        {
            routes.MapUmbracoRoute(
                "accountRoutes",
                "Accout/{action}/{id}",
                new
                {
                    controller = "Account",
                    action = "Index",
                    id =UrlParameter.Optional
                },
                new UmbracoVirtualNodeByIdRouteHandler(1120));
        }

    }
}
